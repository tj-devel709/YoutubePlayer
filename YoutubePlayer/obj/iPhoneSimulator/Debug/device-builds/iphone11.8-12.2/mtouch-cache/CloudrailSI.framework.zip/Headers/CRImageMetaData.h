//
//  CRImageMetaData.h
//  CloudrailSI
//
//  Created by Felipe Cesar on 29/09/16.
//  Copyright © 2016 CloudRail. All rights reserved.
//

#import "CRSandboxObject.h"
@interface CRImageMetaData : CRSandboxObject

@property (nonatomic) long width;
@property (nonatomic) long height;
@end
